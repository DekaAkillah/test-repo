<span>
  Anda telah mengunggah bukti pembayaran. Selanjutnya, tunggu sampai pembayaran anda terkonfirmasi.
</span>
<form 